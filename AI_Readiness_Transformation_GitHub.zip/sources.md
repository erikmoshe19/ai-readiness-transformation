# Sources & Reference Areas

This portfolio is an original synthesis and does not reproduce any single source.

Reference areas used to inform the framework include:

- NIST AI Risk Management Framework (AI RMF)
- NIST Generative AI Profile
- ISO/IEC 42001 AI management-system concepts
- Organizational change-management principles
- Enterprise content and knowledge governance practices
- Human-in-the-loop AI evaluation practices

For a public GitHub repository, add direct source links here after reviewing the current versions of each reference.
