# Responsible AI Governance

Governance should be proportional to use-case risk.

Core controls:

- Acceptable and prohibited uses
- Risk classification
- Human review requirements
- Source verification
- Output testing
- Escalation paths
- Ownership and accountability
- Documentation of approved use cases and recurring issues
