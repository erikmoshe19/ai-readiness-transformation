# Workflow Redesign

Map the current workflow, then identify where AI can assist and where human accountability must remain.

**Current state:** inputs → decisions → actions → outputs → handoffs

Potential AI roles include:

- Drafting
- Summarization
- Classification
- Retrieval
- Comparison
- Pattern identification

Human roles should include judgment, approval, exception handling and accountability where appropriate.
