# Measurement

Use a balanced scorecard.

**Adoption:** active users, repeat use, workflow penetration

**Quality:** error rates, review findings, source accuracy, escalations

**Efficiency:** cycle time, manual effort, turnaround time, rework

**Business outcomes:** service quality, capacity, user experience, realized value

**Governance:** exceptions, policy violations, unresolved risks, control effectiveness
