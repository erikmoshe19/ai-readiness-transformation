# Information Readiness

AI-enabled workflows depend on usable organizational information.

Readiness dimensions:

- Accuracy
- Currency
- Ownership
- Accessibility
- Taxonomy
- Metadata
- Naming conventions
- Version control
- Lifecycle management

Knowledge governance is treated as a supporting transformation capability.
