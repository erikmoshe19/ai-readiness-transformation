# AI Opportunity Assessment

Evaluate candidate workflows against:

- Business value
- Feasibility
- Risk
- Organizational readiness
- Adoption effort

Example evidence to collect:

- Current cycle time
- Repetitive/manual steps
- Error or rework patterns
- Quality criteria
- User pain points
- Data/information dependencies
- Required human judgment
- Security, privacy or regulatory constraints
